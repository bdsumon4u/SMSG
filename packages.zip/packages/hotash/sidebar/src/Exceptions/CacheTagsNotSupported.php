<?php

namespace Hotash\Sidebar\Exceptions;

class CacheTagsNotSupported extends \Exception
{
}
