<a title="{{ $append->getName() }}" class="append pull-right" href="{{ $append->getUrl() }}">
    <i class="{{ $append->getIcon() }}"></i>
</a>
