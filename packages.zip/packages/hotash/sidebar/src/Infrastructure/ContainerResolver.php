<?php

namespace Hotash\Sidebar\Infrastructure;

use Hotash\Sidebar\Exceptions\LogicException;
use Hotash\Sidebar\Sidebar;
use Illuminate\Contracts\Container\Container;

class ContainerResolver implements SidebarResolver
{
    /**
     * @var Container
     */
    protected $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * @return Sidebar
     *
     * @throws LogicException
     */
    public function resolve($name)
    {
        $sidebar = $this->container->make($name);

        if (! $sidebar instanceof Sidebar) {
            throw new LogicException('Your sidebar should implement the Sidebar interface');
        }

        $sidebar->build();

        return $sidebar;
    }
}
