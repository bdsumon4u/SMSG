<?php

namespace Hotash\Sidebar\Exceptions;

class SidebarFlusherNotSupported extends \Exception
{
}
