<?php

namespace Hotash\Sidebar;

interface SidebarExtender
{
    /**
     * @return Menu
     */
    public function extendWith(Menu $menu);
}
