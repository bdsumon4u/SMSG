<?php

namespace Hotash\Sidebar\Infrastructure;

use Illuminate\Contracts\Cache\Repository as Cache;

class StaticSidebarFlusher implements SidebarFlusher
{
    /**
     * @var Cache
     */
    protected $cache;

    public function __construct(Cache $cache)
    {
        $this->cache = $cache;
    }

    /**
     * Flush
     */
    public function flush($name)
    {
        $this->cache->forget(CacheKey::get($name));
    }
}
