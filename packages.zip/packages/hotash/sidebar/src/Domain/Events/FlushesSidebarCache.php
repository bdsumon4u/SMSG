<?php

namespace Hotash\Sidebar\Domain\Events;

use Hotash\Sidebar\SidebarManager;
use Illuminate\Contracts\Container\Container;

class FlushesSidebarCache
{
    /**
     * @var SidebarManager
     */
    protected $manager;

    /**
     * @var Container
     */
    private $container;

    public function __construct(Container $container, SidebarManager $manager)
    {
        $this->manager = $manager;
        $this->container = $container;
    }

    /**
     * Flush the sidebar cache
     */
    public function handle()
    {
        $this->container->call([
            $this->manager,
            'flush',
        ]);
    }
}
