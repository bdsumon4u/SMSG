<?php

namespace Hotash\Sidebar\Infrastructure;

class NullSidebarFlusher implements SidebarFlusher
{
    /**
     * Flush
     */
    public function flush($name)
    {
    }
}
