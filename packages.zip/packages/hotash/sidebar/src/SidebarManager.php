<?php

namespace Hotash\Sidebar;

use Hotash\Sidebar\Exceptions\LogicException;
use Hotash\Sidebar\Infrastructure\SidebarFlusher;
use Hotash\Sidebar\Infrastructure\SidebarResolver;
use Illuminate\Contracts\Container\Container;

class SidebarManager
{
    /**
     * @var array
     */
    protected $sidebars = [];

    protected $container;

    /**
     * @var SidebarResolver
     */
    protected $resolver;

    public function __construct(Container $container, SidebarResolver $resolver)
    {
        $this->container = $container;
        $this->resolver = $resolver;
    }

    /**
     * Register the sidebar
     *
     *
     * @return $this
     *
     * @throws LogicException
     */
    public function register($name)
    {
        if (class_exists($name)) {
            $this->sidebars[] = $name;
        } else {
            throw new LogicException('Sidebar ['.$name.'] does not exist');
        }

        return $this;
    }

    /**
     * Bind sidebar instances to the ioC
     */
    public function resolve()
    {
        foreach ($this->sidebars as $name) {
            $sidebar = $this->resolver->resolve($name);

            $this->container->singleton($name, function () use ($sidebar) {
                return $sidebar;
            });
        }
    }

    public function flush(SidebarFlusher $flusher)
    {
        foreach ($this->sidebars as $name) {
            $flusher->flush($name);
        }
    }
}
