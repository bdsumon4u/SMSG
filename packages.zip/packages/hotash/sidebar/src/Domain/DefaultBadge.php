<?php

namespace Hotash\Sidebar\Domain;

use Hotash\Sidebar\Badge;
use Hotash\Sidebar\Traits\AuthorizableTrait;
use Hotash\Sidebar\Traits\CacheableTrait;
use Hotash\Sidebar\Traits\CallableTrait;
use Illuminate\Contracts\Container\Container;
use Serializable;

class DefaultBadge implements Badge, Serializable
{
    use CallableTrait, CacheableTrait, AuthorizableTrait;

    /**
     * @var Container
     */
    protected $container;

    /**
     * @var mixed
     */
    protected $value = null;

    /**
     * @var string
     */
    protected $class = 'badge badge-default';

    /**
     * @var array
     */
    protected $cacheables = [
        'value',
        'class',
    ];

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @param  mixed  $value
     * @return Badge
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * @return string
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * @param  string  $class
     * @return Badge
     */
    public function setClass($class)
    {
        $this->class = $class;

        return $this;
    }
}
