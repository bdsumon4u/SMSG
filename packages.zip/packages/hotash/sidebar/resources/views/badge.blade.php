<small class="badge pull-right {{ $badge->getClass() }}">{{ $badge->getValue() }}</small>
