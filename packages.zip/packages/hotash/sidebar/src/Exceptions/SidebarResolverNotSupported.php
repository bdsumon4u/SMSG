<?php

namespace Hotash\Sidebar\Exceptions;

class SidebarResolverNotSupported extends \Exception
{
}
