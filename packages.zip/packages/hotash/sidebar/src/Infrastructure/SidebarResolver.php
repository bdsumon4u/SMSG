<?php

namespace Hotash\Sidebar\Infrastructure;

use Hotash\Sidebar\Sidebar;

interface SidebarResolver
{
    /**
     * @param  string  $name
     * @return Sidebar
     */
    public function resolve($name);
}
