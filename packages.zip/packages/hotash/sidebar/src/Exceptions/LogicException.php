<?php

namespace Hotash\Sidebar\Exceptions;

class LogicException extends \LogicException
{
}
