<?php

namespace Hotash\Sidebar\Presentation;

use Hotash\Sidebar\Sidebar;

interface SidebarRenderer
{
    /**
     * @return \Illuminate\Contracts\View\View
     */
    public function render(Sidebar $sidebar);
}
