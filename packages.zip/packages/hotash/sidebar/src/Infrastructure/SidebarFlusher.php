<?php

namespace Hotash\Sidebar\Infrastructure;

interface SidebarFlusher
{
    /**
     * Flush
     */
    public function flush($name);
}
