<?php

namespace Hotash\Sidebar\Infrastructure;

use Hotash\Sidebar\Exceptions\CacheTagsNotSupported;
use Illuminate\Contracts\Cache\Repository;

class SupportsCacheTags
{
    /**
     * @return bool
     *
     * @throws CacheTagsNotSupported
     */
    public function isSatisfiedBy(Repository $repository)
    {
        if (! method_exists($repository->getStore(), 'tags')) {
            throw new CacheTagsNotSupported('Cache tags are necessary to use this kind of caching. Consider using a different caching method');
        }

        return true;
    }
}
