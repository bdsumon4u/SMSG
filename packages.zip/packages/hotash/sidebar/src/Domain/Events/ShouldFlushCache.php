<?php

namespace Hotash\Sidebar\Domain\Events;

interface ShouldFlushCache
{
}
