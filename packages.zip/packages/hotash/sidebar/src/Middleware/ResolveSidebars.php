<?php

namespace Hotash\Sidebar\Middleware;

use Closure;
use Hotash\Sidebar\SidebarManager;

class ResolveSidebars
{
    /**
     * @var SidebarManager
     */
    protected $manager;

    public function __construct(SidebarManager $manager)
    {
        $this->manager = $manager;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $this->manager->resolve();

        return $next($request);
    }
}
