<ul class="sidebar-menu">
    @foreach($groups as $group)
        {!! $group !!}
    @endforeach
</ul>
