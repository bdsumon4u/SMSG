<?php

namespace Hotash\Sidebar\Infrastructure;

use Hotash\Sidebar\Exceptions\SidebarResolverNotSupported;
use Illuminate\Support\Str;

class SidebarResolverFactory
{
    /**
     * @return string
     *
     * @throws SidebarResolverNotSupported
     */
    public static function getClassName($name)
    {
        if ($name) {
            $class = __NAMESPACE__.'\\'.Str::studly($name).'CacheResolver';

            if (class_exists($class)) {
                return $class;
            }

            throw new SidebarResolverNotSupported('Chosen caching type is not supported. Supported: [static, user-based]');
        }

        return __NAMESPACE__.'\\ContainerResolver';
    }
}
